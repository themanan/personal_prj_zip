#include "rclcpp/rclcpp.hpp"
#include "turtlesim/msg/pose.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <cmath>

class TurtleSquare : public rclcpp::Node
{
public:
    TurtleSquare() : Node("turtle_square")
    {
        RCLCPP_INFO(this->get_logger(), "Turtle is drawing a square...");

        // Publisher and Subscriber setup
        turtle_vel_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel", 10);
        turtle_pose_subscriber_ = this->create_subscription<turtlesim::msg::Pose>(
            "/turtle1/pose", 10, std::bind(&TurtleSquare::pose_callback, this, std::placeholders::_1));

        this->declare_parameter<int>("square_width", 2);
        square_width_ = this->get_parameter("square_width").as_int();
        current_side_ = 0;
        stage_ = MOVE_FORWARD;
    }

private:
    enum Stage { MOVE_FORWARD, ROTATE };

    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr turtle_vel_publisher_;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr turtle_pose_subscriber_;
    geometry_msgs::msg::Twist velocity_msg;

    float start_x_, start_y_, start_theta_;
    int square_width_;
    int current_side_;
    Stage stage_;
    bool initialized_ = false;

    void pose_callback(const turtlesim::msg::Pose &msg)
    {
        if (!initialized_) {
            start_x_ = msg.x;
            start_y_ = msg.y;
            start_theta_ = msg.theta;
            initialized_ = true;
        }

        switch (stage_) {
            case MOVE_FORWARD:
                move_forward(msg);
                break;
            case ROTATE:
                rotate(msg);
                break;
        }
    }

    void move_forward(const turtlesim::msg::Pose &msg)
    {
        float distance = std::sqrt(std::pow(msg.x - start_x_, 2) + std::pow(msg.y - start_y_, 2));
        if (distance < square_width_) {
            velocity_msg.linear.x = 1.0; // Move forward
            velocity_msg.angular.z = 0.0;
            turtle_vel_publisher_->publish(velocity_msg);
        } else {
            velocity_msg.linear.x = 0.0;
            turtle_vel_publisher_->publish(velocity_msg);

            RCLCPP_INFO(this->get_logger(), "Side %d completed. Rotating...", current_side_ + 1);

            // Prepare for rotation
            start_theta_ = msg.theta;
            stage_ = ROTATE;
        }
    }

    void rotate(const turtlesim::msg::Pose &msg)
    {
        float angle_turned = std::abs(msg.theta - start_theta_);
        if (angle_turned < 3.14 / 2) { // 90 degrees
            velocity_msg.linear.x = 0.0;
            velocity_msg.angular.z = 0.5; // Rotate
            turtle_vel_publisher_->publish(velocity_msg);
        } else {
            velocity_msg.angular.z = 0.0;
            turtle_vel_publisher_->publish(velocity_msg);

            RCLCPP_INFO(this->get_logger(), "Rotation completed.");

            // Prepare for the next side
            current_side_++;
            if (current_side_ >= 4) {
                RCLCPP_INFO(this->get_logger(), "Square completed!");
                rclcpp::shutdown();
            } else {
                // Updating current location
                start_x_ = msg.x;
                start_y_ = msg.y;
                stage_ = MOVE_FORWARD;
            }
        }
    }
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TurtleSquare>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
