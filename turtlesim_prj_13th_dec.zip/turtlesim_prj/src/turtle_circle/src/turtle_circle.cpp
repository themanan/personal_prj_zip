#include "rclcpp/rclcpp.hpp"
#include "turtlesim/msg/pose.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <cmath>

class TurtleCircle : public rclcpp::Node {
public:
    TurtleCircle() : Node("turtle_circle") {
        RCLCPP_INFO(this->get_logger(), "Turtle is drawing circle...");

        // Publisher and Subscriber setup
        turtle_vel_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel", 10);
        turtle_pose_subscriber_ = this->create_subscription<turtlesim::msg::Pose>(
            "/turtle1/pose", 10, std::bind(&TurtleCircle::pose_callback, this, std::placeholders::_1));
        
        this->declare_parameter<int>("circle_radius", 3);
        circle_radius = this->get_parameter("circle_radius").as_int();
        this->declare_parameter<int>("circle_limit", 1);
        circle_limit = this->get_parameter("circle_limit").as_int();
        
        completed_circles = 0;
        distance = 0.0;
        perimeter = 2 * M_PI * circle_radius;
    }

private:
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr turtle_vel_publisher_;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr turtle_pose_subscriber_;
    geometry_msgs::msg::Twist velocity_msg;

    int circle_radius, circle_limit, completed_circles;
    float distance, perimeter;
    bool initialized_ = false;
    float start_x_, start_y_;

    void pose_callback(const turtlesim::msg::Pose &msg) {
        if (!initialized_) {
            start_x_ = msg.x;
            start_y_ = msg.y;
            initialized_ = true;
        }

        // Calculate distance traveled
        distance += std::sqrt(std::pow(msg.x - start_x_, 2) + std::pow(msg.y - start_y_, 2));
        start_x_ = msg.x;
        start_y_ = msg.y;

        if (distance >= perimeter) {
            completed_circles++;

            // Reset distance for the next circle
            distance = 0.0;

            RCLCPP_INFO(this->get_logger(), "Completed circle %d of %d", completed_circles, circle_limit);

            if (completed_circles >= circle_limit) {
                // Stop the turtle after completing the desired number of circles
                velocity_msg.linear.x = 0.0;
                velocity_msg.angular.z = 0.0;
                turtle_vel_publisher_->publish(velocity_msg);
                RCLCPP_INFO(this->get_logger(), "Circle limit reached. Stopping turtle.");
                rclcpp::shutdown();
            }
        }

        // Continue moving in a circle
        velocity_msg.linear.x = 1.0; // Move forward
        velocity_msg.angular.z = velocity_msg.linear.x / circle_radius; // Set angular velocity
        turtle_vel_publisher_->publish(velocity_msg);
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TurtleCircle>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
