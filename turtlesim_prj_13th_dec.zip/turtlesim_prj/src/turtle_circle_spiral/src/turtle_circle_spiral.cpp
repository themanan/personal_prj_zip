#include "rclcpp/rclcpp.hpp"
#include "turtlesim/msg/pose.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <cmath>

class TurtleCircle : public rclcpp::Node {
public:
    TurtleCircle() : Node("turtle_circle") {
        RCLCPP_INFO(this->get_logger(), "Turtle is drawing circle...");

        // Publisher and Subscriber setup
        turtle_vel_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel", 10);
        turtle_pose_subscriber_ = this->create_subscription<turtlesim::msg::Pose>(
            "/turtle1/pose", 10, std::bind(&TurtleCircle::pose_callback, this, std::placeholders::_1));
        
        this->declare_parameter<int>("circle_radius", 1);
        circle_radius = this->get_parameter("circle_radius").as_int();
        this->declare_parameter<int>("circle_spiral_limit", 1);
        circle_spiral_limit = this->get_parameter("circle_spiral_limit").as_int();
        base_circle_radius = circle_radius;
        completed_circles = 0;
    }

private:
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr turtle_vel_publisher_;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr turtle_pose_subscriber_;
    geometry_msgs::msg::Twist velocity_msg;

    int circle_radius, circle_spiral_limit, base_circle_radius, completed_circles;
    bool initialized_ = false;
    float start_x_, start_y_, start_theta_;

    void pose_callback(const turtlesim::msg::Pose &msg) {
        if (!initialized_) {
            start_x_ = msg.x;
            start_y_ = msg.y;
            start_theta_ = msg.theta;
            initialized_ = true;
        }

        if (msg.theta >= 3.12) {
            circle_radius += base_circle_radius;
                // Continue moving in a circle
            velocity_msg.linear.x = 1.0; // Move forward
            velocity_msg.angular.z = velocity_msg.linear.x / circle_radius; // Set angular velocity
            turtle_vel_publisher_->publish(velocity_msg);
            completed_circles++;
        }

        else if (msg.theta <= -3.12) {
            circle_radius += base_circle_radius;
                // Continue moving in a circle
            velocity_msg.linear.x = 1.0; // Move forward
            velocity_msg.angular.z = velocity_msg.linear.x / circle_radius; // Set angular velocity
            turtle_vel_publisher_->publish(velocity_msg);
            completed_circles++;
        }

        // if (completed_circles >= circle_spiral_limit*2) {
        //     // Stop the turtle after completing the desired number of circles
        //     velocity_msg.linear.x = 0.0;
        //     velocity_msg.angular.z = 0.0;
        //     turtle_vel_publisher_->publish(velocity_msg);
        //     RCLCPP_INFO(this->get_logger(), "Circle limit reached. Stopping turtle., %f",msg.theta);
        //     rclcpp::shutdown();
        // }

        // Continue moving in a circle
        velocity_msg.linear.x = 1.0; // Move forward
        velocity_msg.angular.z = velocity_msg.linear.x / circle_radius; // Set angular velocity
        RCLCPP_INFO(this->get_logger(), "Circle limit reached. Stopping turtle., %f",msg.theta);
        turtle_vel_publisher_->publish(velocity_msg);
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<TurtleCircle>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}


// #include "rclcpp/rclcpp.hpp"
// #include "turtlesim/msg/pose.hpp"
// #include "geometry_msgs/msg/twist.hpp"
// #include <cmath>

// class TurtleCircle : public rclcpp::Node {
// public:
//     TurtleCircle() : Node("turtle_circle") {
//         RCLCPP_INFO(this->get_logger(), "Turtle is drawing a spiraling circle...");

//         // Publisher and Subscriber setup
//         turtle_vel_publisher_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel", 10);
//         turtle_pose_subscriber_ = this->create_subscription<turtlesim::msg::Pose>(
//             "/turtle1/pose", 10, std::bind(&TurtleCircle::pose_callback, this, std::placeholders::_1));
        
//         // Get parameters for circle radius and spiral limit
//         this->declare_parameter<int>("circle_radius", 1);
//         circle_radius = this->get_parameter("circle_radius").as_int();
//         this->declare_parameter<int>("circle_spiral_limit", 1);
//         circle_spiral_limit = this->get_parameter("circle_spiral_limit").as_int();

//         base_circle_radius = circle_radius;
//         completed_circles = 0;
//         current_angle = 0.0;
//     }

// private:
//     rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr turtle_vel_publisher_;
//     rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr turtle_pose_subscriber_;
//     geometry_msgs::msg::Twist velocity_msg;

//     int circle_radius, base_circle_radius, circle_spiral_limit, completed_circles;
//     float current_angle;
//     bool initialized_ = false;

//     void pose_callback(const turtlesim::msg::Pose &msg) {
//         if (!initialized_) {
//             initialized_ = true;
//         }

//         // Check if a full circle (2π radians) has been completed
//         current_angle += velocity_msg.angular.z / 10.0; // Approximate angular increment
//         if (current_angle >= 2 * M_PI) {
//             current_angle = 0.0;
//             completed_circles++;
//             circle_radius += base_circle_radius;

//             RCLCPP_INFO(this->get_logger(), "Completed circle %d of %d", completed_circles, circle_spiral_limit);

//             if (completed_circles >= circle_spiral_limit) {
//                 // Stop the turtle after completing the desired number of circles
//                 velocity_msg.linear.x = 0.0;
//                 velocity_msg.angular.z = 0.0;
//                 turtle_vel_publisher_->publish(velocity_msg);
//                 RCLCPP_INFO(this->get_logger(), "Circle spiral limit reached. Stopping turtle.");
//                 rclcpp::shutdown();
//                 return;
//             }
//         }

//         // Continue moving in a circle
//         velocity_msg.linear.x = 1.0; // Move forward
//         velocity_msg.angular.z = velocity_msg.linear.x / circle_radius; // Adjust angular velocity for the radius
//         turtle_vel_publisher_->publish(velocity_msg);
//     }
// };

// int main(int argc, char **argv) {
//     rclcpp::init(argc, argv);
//     auto node = std::make_shared<TurtleCircle>();
//     rclcpp::spin(node);
//     rclcpp::shutdown();
//     return 0;
// }
