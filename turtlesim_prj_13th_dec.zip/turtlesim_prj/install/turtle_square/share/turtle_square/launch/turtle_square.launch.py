from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    ld = LaunchDescription()

    turtlesim = Node(
        package="turtlesim",
        executable="turtlesim_node",
        output="screen"
    )
    
    turtle_spawn = Node(
        package='turtle_square',
        executable="turtle_square",
        output='screen',
        parameters = [
            {"square_width": 5}
        ]
    )

    ld.add_action(turtlesim)
    ld.add_action(turtle_spawn)
    return ld