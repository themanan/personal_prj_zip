from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import logging

# Initialize logging for debugging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize ROS2
rclpy.init()
node = Node('restaurant_publisher')
publisher = node.create_publisher(String, 'restaurant_order_topic', 10)

app = FastAPI()

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Specify your frontend URL here for better security in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Modify the Order model to accept a list of strings for the order
class Order(BaseModel):
    name: str
    table: int
    order: list[str]  # List of ordered items as strings

@app.post("/publish")
async def publish_order(order: Order, request: Request):
    try:
        # Log the incoming data for debugging
        logger.info(f"Incoming order: {order}")

        # Ensure that the order is not empty
        if not order.order:
            raise HTTPException(status_code=400, detail="Order items cannot be empty")

        # Create and publish the ROS2 message
        ros_msg = String()
        ros_msg.data = f"Customer: {order.name}, Table: {order.table}, Order: {', '.join(order.order)}"
        publisher.publish(ros_msg)
        
        # Log the order being published
        logger.info(f"Published Order: {ros_msg.data}")
        
        return {"detail": "Order published successfully"}
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        logger.error(f"Error publishing order: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Run the server with: uvicorn server:app --reload --port 8000
